from django.shortcuts import render
from django import template
from django.http import HttpResponse


def home(request):
    return render(request, 'templates/index.html')


def hello(request):
    return HttpResponse(u'Hello', content_type="text/plain")
# Create your views here.
